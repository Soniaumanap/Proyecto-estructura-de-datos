/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author brand
 */
public class NodoEntrenadores {
    private Entrenadores entrenador;
    private NodoEntrenadores siguiente;

    public NodoEntrenadores(Entrenadores entrenador) {
        this.entrenador = entrenador;
        this.siguiente = null;
    }

   

    public Entrenadores getEntrenador() {
        return entrenador;
    }

    public void setEntrenador(Entrenadores entrenador) {
        this.entrenador = entrenador;
    }

    public NodoEntrenadores getSiguiente() {
        return siguiente;
    }

    public void setSiguiente(NodoEntrenadores siguiente) {
        this.siguiente = siguiente;
    }
    
            
}
