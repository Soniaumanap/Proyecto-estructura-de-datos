/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author brand
 */
public class PilaEntrenadores {

    private NodoEntrenadores top;

    public PilaEntrenadores() {
        this.top = null;
    }

    public boolean esVacia() {
        if (top == null) {
            return true;
        } else {
            return false;
        }

    }


    public void apilar(Entrenadores entrenador) {
        NodoEntrenadores nuevoNodo = new NodoEntrenadores(entrenador);
        if (esVacia()) {
            top = nuevoNodo;
        } else {
            nuevoNodo.setSiguiente(top);
            top = nuevoNodo;
        }
    }

    public void desapilar() {
        if (!esVacia()) {
            top = top.getSiguiente();

        } else {

        }

    }

    public String toString() {
        String s = "";
        if (!esVacia()) {
            NodoEntrenadores aux = top;
            while (aux != null) {
                s = s + aux.getEntrenador()+ "\n";
                aux = aux.getSiguiente();
            }
        }
        return s;
    }
}
