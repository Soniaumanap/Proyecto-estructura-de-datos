/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author brand
 */
public class Arcanine extends Pokemon implements IFuego{
    public Arcanine() {
        nomPokemon="Arcanine";
        vida=115;
        ataque=50;
        defensa=35;
        ataqueEsp=70;
        defensaEsp=60;
    }
       
    @Override
    public int ataqueLanzallamas() {
        int danio=0;
        return danio;

    }

    @Override
    public int ataqueAnilloIgneo() {
                int danio=0;
        return danio;
    }

    @Override
    public int ataqueColmilloIgneo() {
                int danio=0;
        return danio;
    }

    @Override
    public int ataquepuñoFuego() {
                int danio=0;
        return danio;
    }

    @Override
    public String toString() {
        return "Arcanine" ;
    }
    
}


