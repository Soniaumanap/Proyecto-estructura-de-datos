/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author brand
 */
public class Ursaring extends Pokemon implements INormal {
     public Ursaring() {
        nomPokemon="Ursaring";
        vida=150;
        ataque=50;
        defensa=35;
        ataqueEsp=70;
        defensaEsp=60;
    }
       
    @Override
    public int ataqueHiperrayo() {
        int danio=0;
        return danio;

    }

    @Override
    public int ataqueMeteoronola() {
                int danio=0;
        return danio;
    }

    @Override
    public int ataquePisoton() {
                int danio=0;
        return danio;
    }

    @Override
    public int ataqueVelocitdadExtrema() {
                int danio=0;
        return danio;
    }

    @Override
    public String toString() {
        return "Ursaring";
    }
    
}
