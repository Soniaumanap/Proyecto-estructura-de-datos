/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author brand
 */
public class Main {

    public static void main(String[] args) {
        Pokemon Charizard = new Charizard();
        Pokemon Gyarados = new Gyarados();
        Pokemon Typlosion = new Typlosion();
        Pokemon Snorlax = new Snorlax();
        Pokemon Oranguru = new Oranguru();
        Pokemon Greninja = new Greninja();
        Pokemon Arcanine = new Arcanine();
        Pokemon Swampert = new Swampert();
        Pokemon Ursaring = new Ursaring();

        PilaEntrenadores p = new PilaEntrenadores();
        Entrenadores entrenador1 = new Entrenadores("Brandon", Charizard, Gyarados, Typlosion, Snorlax);
        Entrenadores entrenador2 = new Entrenadores("Sonia", Swampert, Ursaring, Arcanine, Charizard);
        Entrenadores entrenador3 = new Entrenadores("Julia", Greninja, Typlosion, Oranguru, Ursaring);
        Entrenadores entrenador4 = new Entrenadores("Pablo", Charizard, Gyarados, Typlosion, Snorlax);
        Entrenadores entrenador5 = new Entrenadores("Emma", Charizard, Gyarados, Typlosion, Snorlax);
        Entrenadores entrenador6 = new Entrenadores("Yeray", Charizard, Gyarados, Typlosion, Snorlax);
        p.apilar(entrenador1);
        p.apilar(entrenador2);
        p.apilar(entrenador3);
        p.apilar(entrenador4);
        p.apilar(entrenador5);
        p.apilar(entrenador6);
        
        System.out.println(p.toString());
    }
}
