/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */

/**
 *
 * @author brand
 */
public interface INormal {
    //ataques especiales
    public int ataqueHiperrayo();
    public int ataqueMeteoronola();
    //ataques fisicos
    public int ataquePisoton();
    public int ataqueVelocitdadExtrema();
}
