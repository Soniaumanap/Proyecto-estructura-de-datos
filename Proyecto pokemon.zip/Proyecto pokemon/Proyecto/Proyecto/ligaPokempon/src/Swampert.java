/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author brand
 */
public class Swampert extends Pokemon implements IAgua{
     public Swampert() {
        nomPokemon="Swampert";
        vida=190;
        ataque=55;
        defensa=45;
        ataqueEsp=75;
        defensaEsp=65;
    }
       
    @Override
    public int ataqueHidroBomba() {
        int danio=0;
        return danio;

    }

    @Override
    public int ataqueSurf() {
                int danio=0;
        return danio;
    }

    @Override
    public int ataqueMartillazo() {
                int danio=0;
        return danio;
    }

    @Override
    public int ataqueAquaCola() {
                int danio=0;
        return danio;
    }

    @Override
    public String toString() {
        return "Swampert"  ;
    }
    
}

