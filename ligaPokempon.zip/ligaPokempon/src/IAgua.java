/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */

/**
 *
 * @author brand
 */
public interface IAgua {
//ataques especiales
    public int ataqueHidroBomba(Pokemon defensor);
    public int ataqueSurf(Pokemon defensor);

//Ataques fisicos
    public int ataqueMartillazo(Pokemon defensor);
    public int ataqueAquaCola(Pokemon defensor);

}