
import javax.swing.JTextArea;


public class Batalla {

    private final EntrenadorUsu entrenadorUsuario;
    private final Entrenadores entrenadorAdversario;
    private Object ganador;
    private final JTextArea outputTextArea ;  

    public Object getGanador() {
        return ganador;
    }

    public Batalla(EntrenadorUsu entrenadorUsuario, Entrenadores entrenadorAdversario, JTextArea outputTextArea) {
        this.entrenadorUsuario = entrenadorUsuario;
        this.entrenadorAdversario = entrenadorAdversario;
         this.outputTextArea = outputTextArea;
    }

    public void iniciarBatalla() {
        outputTextArea.append("¡Comienza la batalla! \n");
        outputTextArea.append("\n");
        Pokemon pokemonUsuario = entrenadorUsuario.elegirPokemonParaBatalla();
        Pokemon pokemonAdversario = entrenadorAdversario.elegirPokemonParaBatalla();
        outputTextArea.append("El entrenador " + entrenadorUsuario.getNombre() + " envía a " + pokemonUsuario.getNomPokemon() + " a la batalla. \n");
        outputTextArea.append("\n");
        outputTextArea.append("El entrenador " + entrenadorAdversario.getNombre() + " envía a " + pokemonAdversario.getNomPokemon() + " a la batalla. \n");
        outputTextArea.append("\n");
        while (entrenadorUsuario.tienePokemonVivo() && entrenadorAdversario.tienePokemonVivo()) {
            outputTextArea.append("\n");
            outputTextArea.append("Inicia un nuevo turno.\n");
            outputTextArea.append("\n");
            

            realizarTurno(pokemonUsuario, pokemonAdversario);
            pokemonUsuario = entrenadorUsuario.elegirPokemonParaBatalla();
            pokemonAdversario = entrenadorAdversario.elegirPokemonParaBatalla();
        }

        determinarGanador();
        ganador = determinarGanador();
    }

    public void realizarTurno(Pokemon pokemonUsuario, Pokemon pokemonAdversario) {
        if (!pokemonUsuario.estaVivo()) {
            outputTextArea.append(pokemonUsuario.getNomPokemon() + " no puede atacar. ¡Está fuera de combate! \n");
            outputTextArea.append("\n");
            return;
        } else {
            int danioUsuario = pokemonUsuario.elegirAtaque(pokemonAdversario);
            pokemonAdversario.recibirDanio(danioUsuario);

        }

        if (!pokemonAdversario.estaVivo()) {
            outputTextArea.append(pokemonAdversario.getNomPokemon() + " no puede atacar. ¡Está fuera de combate! \n");
            outputTextArea.append("\n");
            return;
        } else {

            int danioAdversario = pokemonAdversario.elegirAtaqueAleatorio(pokemonUsuario);
            pokemonUsuario.recibirDanio(danioAdversario);
        }

        outputTextArea.append("Estado actual de " + pokemonUsuario.getNomPokemon() + ": " + pokemonUsuario.getVida() + " HP \n");
        outputTextArea.append("\n");
        outputTextArea.append("Estado actual de " + pokemonAdversario.getNomPokemon() + ": " + pokemonAdversario.getVida() + "HP");
        outputTextArea.append("\n");
    }

    private Object determinarGanador() {
        if (entrenadorUsuario.tienePokemonVivo()) {
            System.out.println("¡El entrenador " + entrenadorUsuario.getNombre() + " ha ganado la batalla! ");
            outputTextArea.append("\n");
            return entrenadorUsuario;
        } else {
            System.out.println("¡El entrenador " + entrenadorAdversario.getNombre() + " ha ganado la batalla! ");
            outputTextArea.append("\n");
            return entrenadorAdversario;
        }
    }
}
