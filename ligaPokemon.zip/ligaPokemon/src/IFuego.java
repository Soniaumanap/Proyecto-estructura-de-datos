/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */

/**
 *
 * @author brand
 */
public interface IFuego {
    //ataques especiales
    public int ataqueLanzallamas(Pokemon defensor);
    public int ataqueAnilloIgneo(Pokemon defensor);
    //ataques fisicos
    public int ataqueColmilloIgneo(Pokemon defensor);
     public int ataquePuñoFuego(Pokemon defensor);
}
