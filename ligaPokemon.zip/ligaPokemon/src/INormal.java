/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */

/**
 *
 * @author brand
 */
public interface INormal {
    //ataques especiales
    public int ataqueHiperrayo(Pokemon defensor);
    public int ataqueMeteoronola(Pokemon defensor);
    //ataques fisicos
    public int ataquePisoton(Pokemon defensor);
    public int ataqueVelocitdadExtrema(Pokemon defensor);
}
