
import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.SwingUtilities;


public class TorneopokemonGUI extends JFrame {
    private JTextArea outputTextArea;
    private JButton startTournamentButton;

    public TorneopokemonGUI() {
        setTitle("Torneo Pokémon");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(800, 600);
        setLayout(new BorderLayout());

        outputTextArea = new JTextArea();
        outputTextArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(outputTextArea);

        startTournamentButton = new JButton("Iniciar Torneo");
        startTournamentButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                startTournament();
            }
        });

        JPanel buttonPanel = new JPanel();
        buttonPanel.add(startTournamentButton);

        add(scrollPane, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);
    }

    private void startTournament() {
        String nombre = JOptionPane.showInputDialog("Digite su nombre");
        Entrenadores entrenadorUsu = new Entrenadores(nombre);
        EntrenadorUsu entrenadorUsu2 = new EntrenadorUsu(nombre);
        ColaTorneo torneo = new ColaTorneo();
        torneo.encola(entrenadorUsu);
        seleccionarPokemonsUsu(entrenadorUsu2, entrenadorUsu);

        agregarEntrenadoresDePrueba(15, torneo);
        outputTextArea.append(torneo.toString());
        outputTextArea.append("\n"); 

        ejecutarTorneo(torneo, "Octavos de Final", entrenadorUsu2);

        outputTextArea.append("¡El ganador del torneo es: " + torneo.atiende() + "!\n\n");
        outputTextArea.append("\n"); 
        
    }

    private void ejecutarTorneo(ColaTorneo cola, String nombreRonda, EntrenadorUsu entrenador) {
        int rondas = cola.tamano() / 2;
        for (int i = 0; i < rondas; i++) {
            ejecutarRonda(cola, nombreRonda, entrenador);
            nombreRonda = nombreSiguienteRonda(nombreRonda);
        }
    }

    private void ejecutarRonda(ColaTorneo cola, String nombreRonda, EntrenadorUsu entrenador) {
        System.out.println("-- " + nombreRonda + " --");
        int partidos = cola.tamano() / 2;
        for (int i = 0; i < partidos; i++) {
            NodoEntrenadores equipo1 = cola.atiende();
            NodoEntrenadores equipo2 = cola.atiende();

            NodoEntrenadores ganador = simularBatalla(equipo1, equipo2, entrenador);

            cola.encola(ganador.getEntrenador());

            outputTextArea.append("Combate " + (i + 1) + ": " + equipo1 + " vs " + equipo2 + "\n" + " --- Ganador: " + ganador + "\n");
           
        }

        if (cola.tamano() > 1) {
            ejecutarRonda(cola, "Siguiente Ronda ", entrenador);
        }
    }
    
    
    

   private  NodoEntrenadores simularBatalla(NodoEntrenadores equipo1, NodoEntrenadores equipo2, EntrenadorUsu entrenador) {
        
         if (equipo1.getEntrenador().getNombre().equals(entrenador.getNombre())) {
            Batalla b1 = new Batalla(entrenador, equipo2.getEntrenador(),outputTextArea);
            b1.iniciarBatalla();
            entrenador.restaurarVidaPokemon();
            equipo1.getEntrenador().restaurarVidaPokemon();
            equipo2.getEntrenador().restaurarVidaPokemon();
            if (b1.getGanador() == entrenador) {
                return equipo1;
            } else {
                return equipo2;
            }
        } else if (equipo2.getEntrenador().getNombre().equals(entrenador.getNombre())) {
            Batalla b1 = new Batalla(entrenador, equipo1.getEntrenador(),outputTextArea);
            b1.iniciarBatalla();
            entrenador.restaurarVidaPokemon();
            equipo1.getEntrenador().restaurarVidaPokemon();
            equipo2.getEntrenador().restaurarVidaPokemon();
            if (b1.getGanador() == entrenador) {
                return equipo2;
            } else {
                return equipo1;
            } 
        } else {
            double probabilidad = Math.random();
            equipo1.getEntrenador().restaurarVidaPokemon();
            equipo2.getEntrenador().restaurarVidaPokemon();            
            return probabilidad > 0.5 ? equipo1 : equipo2;

        }
        
    }

    public static void agregarEntrenadoresDePrueba(int cantidad, ColaTorneo torneo) {
        String[] nombres = {"Ash \n", "Gary \n", "Misty \n", "Brock \n", "May \n", "Dawn \n", "Red \n", "Blue \n", "Leaf \n", "Serena \n", "Cynthia \n",  "Pescador \n", "Ethan \n", "Lyra \n", "Suarez \n"};
        for (int i = 0; i < cantidad; i++) {

            Entrenadores entrenador = new Entrenadores(nombres[i]);
            agregarPokemonesAleatorios(entrenador);
            System.out.println(nombres[i]);
           
            torneo.encola(entrenador);
        }

    }
    
    private String nombreSiguienteRonda(String nombreRondaActual) {
        switch (nombreRondaActual) {
            case "Octavos de Final \n":
                return "Cuartos de Final \n";
            case "Cuartos de Final \n":
                return "Semifinales \n";
            case "Semifinales \n":
                return "Final \n";
            default:
                return "Final \n";
        }
    }
    
    private static void agregarPokemonesAleatorios(Entrenadores entrenador) {
        int sumador = 0;
        while (sumador != 4) {
            Pokemon pokemonAleatorio = PokemonAleatorios.generarPokemonAleatorio();
            NodoPokemon aux = entrenador.getConjuntoPokemons().top;
            boolean esta = false;
            while (aux != null) {
                if (aux.getPokemon().nomPokemon.equals(pokemonAleatorio.nomPokemon)) {
                    esta = true;
                }
                aux = aux.getSiguiente();
            }
            if (esta == false) {
                entrenador.getConjuntoPokemons().apilar(pokemonAleatorio);
                sumador += 1;
            }
        }

    }
    
    private static void seleccionarPokemonsUsu(EntrenadorUsu entrenador, Entrenadores entrenadorUsu) {
        int sumador = 0;
        while (sumador != 4) {
            Pokemon pokemonSeleccionado =seleccionarPokemon();
            NodoListaPokemon aux = entrenador.getPokemons().cabeza;
            boolean esta = false;
            while (aux != null) {
                if (aux.getPokemon().nomPokemon.equals(pokemonSeleccionado.nomPokemon)) {
                    esta = true;
                    JOptionPane.showMessageDialog(null, "El pokemon ya se encuentra en su Pokedex");
                }
                aux = aux.getSiguiente();
            }
            if (esta == false) {
                entrenador.getPokemons().inserta(pokemonSeleccionado);
                sumador += 1;
            }
        }

    }
    
    public static Pokemon seleccionarPokemon() {
    String[] opciones = {"Charizard", "Swampert", "Ursaring", "Arcanine", "Typlosion", "Snorlax", "Greninja", "Gyarados", "Oranguru"};

    int eleccionIndice = JOptionPane.showOptionDialog(
            null,
            "Elige el Pokémon que desees:",
            "Seleccionar Pokémon",
            JOptionPane.DEFAULT_OPTION,
            JOptionPane.QUESTION_MESSAGE,
            null,
            opciones,
            opciones[0]);

    if (eleccionIndice >= 0 && eleccionIndice < opciones.length) {
        switch (eleccionIndice) {
            case 0:
                return new Charizard();
            case 1:
                return new Swampert();
            case 2:
                return new Ursaring();
            case 3:
                return new Arcanine();
            case 4:
                return new Typlosion();
            case 5:
                return new Snorlax();
            case 6:
                return new Greninja();
            case 7:
                return new Gyarados();
            case 8:
                return new Oranguru();
            default:
                return null;
        }
    } else {
        return null;
    }
}
    
    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                TorneopokemonGUI gui = new TorneopokemonGUI();
                gui.setVisible(true);
            }
        });
    }
}
    
    
